var ValidationResult = function(isValid) {
  this.isValid = isValid;
  this.errors = [];
  this.warnings = [];

  this.assertError = function(condition, key, message){
    if(condition){
      this.isValid = false;
      this.errors.push({ key: key, message: message });
    }
  }

  this.assertWarning = function(condition, key, message){
    if(condition){
      this.warnings.push({ key: key, message: message });
    }
  }
}