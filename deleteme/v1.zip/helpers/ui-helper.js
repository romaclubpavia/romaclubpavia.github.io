const uiHelper = function(){

  this.buttonIcon = function(clsName, onClick, data) {
    const btn = document.createElement('i');
    if (data && data.length > 0){
      for(let i = 0; i < data.length; i++){
        btn.dataset[data[i].name] = data[i].value;
      }
    }
    btn.classList.add('bi', clsName);
    btn.addEventListener('click', onClick);
    return btn;
  }

  this.fieldReset = function(options) {
    document.getElementById(options.id).value = options.value;
    if (options.validations){
      //document.getElementById(options.id + '-valid').innerHTML = '';
      document.getElementById(options.id + '-invalid').innerHTML = '';
    }
  }

  this.iconByContentType = function(content){
    const i = document.createElement('i');
    i.classList.add('bi', this.iconClsByContentType(content.contentType));
    return i;
  }

  this.iconClsByContentType = function(contentType){
    let clsName = '';
    if (contentType == 'Card'){
      clsName = 'bi-credit-card'; 
    } else if (contentType == 'Contact'){
      clsName = 'bi-file-person'; 
    } else if (contentType == 'Login'){
      clsName = 'bi-file-earmark-lock'; 
    } else if (contentType == 'Note'){
      clsName = 'bi-file-text'; 
    } else if (contentType == 'Pin'){
      clsName = 'bi-file-binary'; 
    }


    return clsName;
  }

  this.passwordCopy = function(ev){
    var pwInput = ev.target.closest('.pw-dv').querySelector('.pw-in');
  
    pwInput.select();
    pwInput.setSelectionRange(0, 99999);
  
    navigator.clipboard.writeText(pwInput.value);
  }

  this.passwordGenerate = function(ev){
    var pwInput = ev.target.closest('.pw-dv').querySelector('.pw-in');
    pwInput.value = 'pasquale';
  }

  this.passwordTypeToggle = function(ev){
    var pwInput = ev.target.closest('.pw-dv').querySelector('.pw-in');
  
    if (pwInput.type == 'text'){
      pwInput.type = 'password';
      ev.target.closest('.pw-dv').querySelector('.zz-pwhide').style.display = 'none';
      ev.target.closest('.pw-dv').querySelector('.zz-pwshow').style.display = 'block';
    } else {
      pwInput.type = 'text';
      ev.target.closest('.pw-dv').querySelector('.zz-pwhide').style.display = 'block';
      ev.target.closest('.pw-dv').querySelector('.zz-pwshow').style.display = 'none';
    }
  }

  this.validationFormUpdate = function(frmSelector, vr){
    const frm = document.querySelector(frmSelector);
    const invalidElements = frm.querySelectorAll('.invalid-feedback');
    for(let i = 0; i < invalidElements.length; i++) {
      invalidElements[i].innerHTML = '';
    }

    for(let i = 0; i < vr.errors.length; i++){
      frm.querySelector('#' + vr.errors[i].key + '-invalid').innerHTML = vr.errors[i].message;
    }

  }
}