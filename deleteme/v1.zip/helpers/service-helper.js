const serviceHelper = function(){
    
    this.getById = function(items, id){
        for(let i = 0; i < items.length; i++){
            if (items[i].id == id){
                return items[i];
            }
        }
        return null;
    };

    this.getNewId = function(items){
        let newId = 1;
        for(let i = 0; i < items.length; i++){
            if (items[i].id >= newId){
                newId = items[i].id + 1;
            }
        }
        return newId;
    }

    this.removeById = function(items, id){
        let idx = -1;
        
        for(let i = 0; i < items.length; i++){
            if (items[i].id == id){
                idx = i;
                break;
            }
        }
        if (idx > -1){
            items.splice(idx, 1);
        }
    }

}