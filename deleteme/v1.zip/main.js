const contentType = [
  'Card',
  'Contact',
  'Login',
  'Note',
  'Pin'
];

let _vm = {
  folders: [
    { id: 1,  name: 'Contacts', parentFolder: null, isUsed: true },
    { id: 2,  name: 'Logins',   parentFolder: null, isUsed: true },
    { id: 3,  name: 'Notes',    parentFolder: null, isUsed: true },
    { id: 4,  name: 'RCP',      parentFolder: 1,    isUsed: true },
    { id: 5,  name: 'Work',     parentFolder: 1,    isUsed: true },
    { id: 6,  name: 'Work 1',   parentFolder: 5,    isUsed: true },
    { id: 7,  name: 'Work 2',   parentFolder: 5,    isUsed: true },
    { id: 8,  name: 'Cards',    parentFolder: null, isUsed: true },
    { id: 9,  name: 'Deleteme', parentFolder: null, isUsed: false },
    { id: 10, name: 'Pins',     parentFolder: null, isUsed: true }
  ],

  contents: [
    { id: 4, contentType: 'Card',    folderId: 8,    displayName: 'Carta 1', number: '123412341234', expiryMonth: 1, expireYear: 2020, cvv: '', notes: '' },
  
    { id: 1, contentType: 'Contact', folderId: null, displayName: 'Pia',     firstName: 'Pia',    lastName: 'Telande',   email: 'pia@telande.it',   phoneNumber: '11 22 33 44', notes: '' },
    { id: 2, contentType: 'Contact', folderId: 7,    displayName: 'Max',     firstName: 'Max',    lastName: 'DellaPena', email: 'max@dellapena.it', phoneNumber: '22 33 44 55', notes: ''  },
  
    { id: 3, contentType: 'Login',   folderId: 2,    displayName: 'IDApple', username: '1001010', password: '*1pippo*1', otp: null, uri: 'http://www.io.it', notes: ''  },
  
    { id: 5,  contentType: 'Note',   folderId: 3,    displayName: 'Auto',     notes: '132.600' },
    { id: 11, contentType: 'Note',   folderId: 3,    displayName: 'Nota',     notes: 'Bla bla bla' },

    { id: 6, contentType: 'Pin',     folderId: 10,   displayName: 'Pin IPAD', notes: '123456' },
  ]
};

let _currentFolder = null;

let _masterPassword = '';
const _uiHelper = new uiHelper();
const _serviceHelper = new serviceHelper();
const _cryptService = new cryptService();
const _folderService = new folderService(_vm.folders, _serviceHelper)
const _folderController = new folderController(_folderService, _uiHelper);
const _contentService = new contentService([], _serviceHelper);
const _contentController = new contentController(_contentService, _uiHelper);

const _modalMasterPassword = new bootstrap.Modal(document.getElementById('mdMasterPassword'), {});
const _modalViewData = new bootstrap.Modal(document.getElementById('mdViewData'), {});
const _modalOpenData = new bootstrap.Modal(document.getElementById('mdOpenData'), {});

const contentLoginSave = function(){
  _contentController.saveLogin(_currentFolder);
}

const loadNewData = function(){
  _folderService.setItems(_vm.folders);
  _contentService.setItems(_vm.contents);
  //_folderController.setFolderService(_folderService);
  //_contentController.setContentService(_contentService);
  _folderController.foldersDisplay();
  _contentController.contentsDisplay();
}

const folderInit = function() {
  document.getElementById('btNewFolder').addEventListener('click', folderNew, false);
  document.getElementById('btFolderSave').addEventListener('click', folderSave, false);
}

const folderNew = function(){
  _folderController.open();
}

const folderSave = function(){
  _folderController.save();
}

const newItemAppend = function(el, label, onClick){
  const li = document.createElement('li');
  const anchor = document.createElement('a');
  anchor.classList.add('dropdown-item');
  anchor.appendChild(document.createTextNode(label));
  anchor.addEventListener('click', onClick, false);
  li.appendChild(anchor);
  el.appendChild(li);
}

const cardNew = function(){

}

const contactNew = function(){

}

const loginNew = function(){

}
const noteNew = function(){

}
const pinNew = function(){

}

const btOpenDataShowOnClick = function(){
  _uiHelper.fieldReset({id: 'opendata', value: '', validations: true });
  _modalOpenData.show({});
}

const btOpenDataOnClick = function() {
  const dc = _cryptService.decrypt(document.getElementById('opendata').value, _masterPassword);
  _vm = JSON.parse(dc);
  _modalOpenData.hide({});
  loadNewData();
}

const saveAllOnClick = function(){
  var obj = {
    folders: _folderService.getItems(),
  };

  const ct = _cryptService.encrypt(JSON.stringify(obj), _masterPassword);
 
  _uiHelper.fieldReset({id: 'viewdata', value: ct, _masterPassword, validations: true });
  _modalViewData.show({});

}

const masterPasswordSaveOnClick = function(){
  _masterPassword = document.getElementById('masterPassword').value;
  _modalMasterPassword.hide();
}

const masterPasswordShow = function(){
  _uiHelper.fieldReset({id: 'masterPassword', value: _masterPassword, validations: true });
  _modalMasterPassword.show({});
}

const masterPasswordInit = function(){
  document.getElementById('bt-mp-pwhide').addEventListener('click', _uiHelper.passwordTypeToggle, false);
  document.getElementById('bt-mp-pwshow').addEventListener('click', _uiHelper.passwordTypeToggle, false);
  document.getElementById('bt-mp-pwcopy').addEventListener('click', _uiHelper.passwordCopy, false);
  document.getElementById('bt-mp-pwgen').addEventListener('click', _uiHelper.passwordGenerate, false);
  document.getElementById('btMasterPasswordShow').addEventListener('click', masterPasswordShow, false);
  document.getElementById('btMasterPasswordSave').addEventListener('click', masterPasswordSaveOnClick, false);
}

const globalInit = function() {
  document.getElementById('btOpenDataShow').addEventListener('click', btOpenDataShowOnClick, false);
  document.getElementById('btOpenData').addEventListener('click', btOpenDataOnClick, false);
  document.getElementById('btSaveAll').addEventListener('click', saveAllOnClick, false);

  document.getElementById('btLoginSave').addEventListener('click', contentLoginSave, false);
}

const newItemInit = function() {
  const el = document.getElementById('ddNewContent');
  newItemAppend(el, 'Card', cardNew);
  newItemAppend(el, 'Contact', contactNew);
  newItemAppend(el, 'Folder', folderNew);
  newItemAppend(el, 'Login', loginNew);
  newItemAppend(el, 'Note', noteNew);
  newItemAppend(el, 'Pin', pinNew);
}

const main = function() {
  masterPasswordInit();
  folderInit();
  newItemInit();
  globalInit();
  
  //masterPasswordShow();
  loadNewData();
}

main();