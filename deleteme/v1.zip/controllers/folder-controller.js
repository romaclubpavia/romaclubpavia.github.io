const folderController = function(folderService, uiHelper) {

    this.folderService = folderService;
    this.uiHelper = uiHelper;

    const options = {};
    const _modal = new bootstrap.Modal(document.getElementById('mdFolder'), options);

    this.foldersDisplay = function() {
        const tBody = document.getElementById('tbFolder');
        tBody.innerHTML = '';
        var folders = this.folderService.getItems();
        for(let i = 0; i < folders.length; i++){
            if (folders[i].parentFolder == null){
                const newRow = tBody.insertRow();

                const cellId = newRow.insertCell();
                cellId.appendChild(document.createTextNode(folders[i].id));

                const cellName = newRow.insertCell();
                cellName.appendChild(document.createTextNode(folders[i].name));
                
                const cellBtnEdit = newRow.insertCell();
                const editEl = this.uiHelper.buttonIcon('bi-folder2-open', (e) => this.view(e), [{ name: 'id', value: folders[i].id }]);
                cellBtnEdit.appendChild(editEl);

                const cellBtnDel = newRow.insertCell();
                const delEl = this.uiHelper.buttonIcon('bi-trash', (e) => this.remove(e), [{ name: 'id', value: folders[i].id }]);
                cellBtnDel.appendChild(delEl);
            }
        }
    }

    this.open = function(){
        this.show({ id: 0, name: '' });
    }

    this.save = function() {
        const folder = { id: document.getElementById('folder-id').value, name: document.getElementById('folder-name').value };
        var res = this.folderService.save(folder);
        this.foldersDisplay();
        _modal.hide();
    }

    this.setFolderService = function(folderService){
        this.folderService = folderService;
    }
    
    this.show = function(folder) {
        document.getElementById('folder-id').value = folder.id;
        this.uiHelper.fieldReset({id: 'folder-name', value: folder.name, validations: true });
        _modal.show();
    }

    this.remove = function(e) {
        var res = this.folderService.removeById(e.currentTarget.dataset.id);
        this.foldersDisplay();
    }

    this.view = function(e) {
        this.show(this.folderService.getItem(e.currentTarget.dataset.id));
    }
}