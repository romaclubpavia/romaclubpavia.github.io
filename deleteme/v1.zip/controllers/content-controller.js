const contentController = function(contentService, uiHelper) {

  this.contentService = contentService;
  this.uiHelper = uiHelper;

  const options = {};
  //const _modalCard = new bootstrap.Modal(document.getElementById('mdCard'), options);
  //const _modalContact = new bootstrap.Modal(document.getElementById('mdContact'), options);
  const _modalLogin = new bootstrap.Modal(document.getElementById('mdLogin'), options);
  //const _modalNote = new bootstrap.Modal(document.getElementById('mdNote'), options);
  //const _modalPin = new bootstrap.Modal(document.getElementById('mdPin'), options);

  this.contentsDisplay = function(folderId) {
        
    const tBody = document.getElementById('tbContent');
    tBody.innerHTML = '';
    var contents = this.contentService.getItems();
    for(let i = 0; i < contents.length; i++){
        if (folderId == null || folderId == contents[i].folderId){
            const newRow = tBody.insertRow();

            const cellType = newRow.insertCell();
            cellType.appendChild(this.uiHelper.iconByContentType(contents[i]));

            const cellName = newRow.insertCell();
            cellName.appendChild(document.createTextNode(contents[i].displayName));
            
            const cellBtnEdit = newRow.insertCell();
            const editEl = this.uiHelper.buttonIcon('bi-folder2-open', (e) => this.view(e), [{ name: 'id', value: contents[i].id }]);
            cellBtnEdit.appendChild(editEl);

            const cellBtnDel = newRow.insertCell();
            const delEl = this.uiHelper.buttonIcon('bi-trash', (e) => this.remove(e, folderId), [{ name: 'id', value: contents[i].id }]);
            cellBtnDel.appendChild(delEl);
        }
    }
  }

  this.open = function(){
    this.show({ id: 0, name: '' });
  }

  this.saveLogin = function(folder) {
    const content = { 
      id: document.getElementById('login-id').value, 
      contentType: 'Login',
      displayName: document.getElementById('login-displayname').value,
      username: document.getElementById('login-username').value,
      password: document.getElementById('login-password').value,
      uri: document.getElementById('login-uri').value,
      otp: document.getElementById('login-otp').value,
      notes: document.getElementById('login-notes').value
    };

    let vr = this.validateLogin(content);
    if (vr.isValid){
      vr = this.contentService.saveLogin(content);
    }
    if (vr.isValid){
      this.contentsDisplay(folder);
      _modalLogin.hide();
    } else {
      this.uiHelper.validationFormUpdate('#frm-login', vr);
    }
  }

  this.show = function(content) {
    // switch sul type, set and open form
    if (content.contentType == 'Card') {
      document.getElementById('card-id').value = content.id;
      document.getElementById('card-name').value = content.name;
      document.getElementById('card-name-valid').innerHTML = '';
      document.getElementById('card-name-invalid').innerHTML = '';
      _modalCard.show();
    } else if (content.contentType == 'Contact') {
      document.getElementById('folder-name').value = content.name;
      document.getElementById('folder-id').value = content.id;
      document.getElementById('folder-name-valid').innerHTML = '';
      document.getElementById('folder-name-invalid').innerHTML = '';
      _modalContact.show();
    } else if (content.contentType == 'Login') {
      this.uiHelper.fieldReset({id: 'login-id', value: content.id, validations: false });
      this.uiHelper.fieldReset({id: 'login-displayname', value: content.displayName, validations: true });
      this.uiHelper.fieldReset({id: 'login-username', value: content.username, validations: true });
      this.uiHelper.fieldReset({id: 'login-password', value: content.password, validations: true });
      this.uiHelper.fieldReset({id: 'login-otp', value: content.otp, validations: true });
      this.uiHelper.fieldReset({id: 'login-uri', value: content.uri, validations: true });
      this.uiHelper.fieldReset({id: 'login-notes', value: content.notes, validations: false });
      _modalLogin.show();
    } else if (content.contentType == 'Note') {
      document.getElementById('folder-name').value = content.name;
      document.getElementById('folder-id').value = content.id;
      document.getElementById('folder-name-valid').innerHTML = '';
      document.getElementById('folder-name-invalid').innerHTML = '';
      _modalNote.show();
    } else if (content.contentType == 'Pin') {
      document.getElementById('folder-name').value = content.name;
      document.getElementById('folder-id').value = content.id;
      document.getElementById('folder-name-valid').innerHTML = '';
      document.getElementById('folder-name-invalid').innerHTML = '';
      _modalPin.show();
    }
  }

  this.remove = function(e, folderId) {
    var res = this.contentService.removeById(e.currentTarget.dataset.id);
    this.contentsDisplay(folderId);
  }

  this.validateLogin = function(content) {
    const validator = new SimpleValidator();
    
    const vr = new ValidationResult();
    if (content == null){
      vr.assertError(true, '', 'Request not valid'); //TODOLB
      return vr;
    }

    validator.validateString('Display Name', 'login-displayname', content.displayName, { required: true, minLength: 2, maxLength: 100 }, vr);//TODOLB
    return vr;
  }

  this.view = function(e) {
    this.show(this.contentService.getItem(e.currentTarget.dataset.id));
  }

  const init = function() {
    document.getElementById('bt-login-pwhide').addEventListener('click', this.uiHelper.passwordTypeToggle, false);
    document.getElementById('bt-login-pwshow').addEventListener('click', this.uiHelper.passwordTypeToggle, false);
    document.getElementById('bt-login-pwcopy').addEventListener('click', this.uiHelper.passwordCopy, false);
    document.getElementById('bt-login-pwgen').addEventListener('click', this.uiHelper.passwordGenerate, false);
  }

  init.bind(this)();
}

var SimpleValidator = function() {
  
  this.validateString = function(fieldName, fieldKey, fieldValue, options, vr) {
    if (options.required) {
      if (fieldValue === undefined || fieldValue === null || fieldValue === '' || fieldValue.trim() === ''){
        vr.assertError(true, fieldKey, fieldKey + ' is required');// TODOLB
      }
    }
  }
}