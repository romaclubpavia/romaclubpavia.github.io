const cryptService = function(){
  
  this.encrypt = function(data, pw) {
    return CryptoJS.AES.encrypt(data, pw).toString();
  }

  this.decrypt = function(data, pw){
    return CryptoJS.AES.decrypt(data, pw).toString(CryptoJS.enc.Utf8);
  }
}