const folderService = function(items, serviceHelper) {
    this.items = items;
    this.serviceHelper = serviceHelper;

    this.getItem = function(id){
        return this.serviceHelper.getById(this.items, id);
    };

    this.getItems = function(){
        return this.items;
    };

    this.removeById = function(id) {
        this.serviceHelper.removeById(this.items, id);
    }

    this.save = function(item){
        if (item.id <= 0) {
            item.id = this.serviceHelper.getNewId(this.items);
            this.items.push(item);
            return true;
        } else {
            for(let i = 0; i < this.items.length; i++){
                if (this.items[i].id == item.id){
                    this.items[i].name = item.name;
                    return true;
                }
            }
        }
        return false;
    }

    this.setItems = function(items){
        this.items = items;
    };
}

