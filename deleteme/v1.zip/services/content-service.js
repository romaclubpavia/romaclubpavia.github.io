const contentService = function(items, serviceHelper) {
  this.items = items;
  this.serviceHelper = serviceHelper;
  this.getItem = function(id){
    return this.serviceHelper.getById(this.items, id);
  };

  this.getItems = function(){
    return this.items;
  };

  this.mapLogin = function(oldContent, newContent){
    oldContent.displayName = newContent.displayName;
    oldContent.folderId = newContent.folderId;
    oldContent.username = newContent.username;
    oldContent.password = newContent.password;
    oldContent.uri = newContent.uri;
    oldContent.otp = newContent.otp;
    oldContent.notes = newContent.notes;
  }

  this.removeById = function(id) {
    this.serviceHelper.removeById(this.items, id);
  }

  this.save = function(item, options) {
    if (item.id <= 0) {
      item.id = this.serviceHelper.getNewId(this.items);
      this.items.push(item);
      return new ValidationResult(true);
    } else {
      for(let i = 0; i < this.items.length; i++){
        if (this.items[i].id == item.id){
          options.mapFn(this.items[i], item);
          return new ValidationResult(true);
        }
      }
    }
    return new ValidationResult(false);
  }

  this.saveLogin = function(item){
    const options = { mapFn: this.mapLogin };
    return this.save(item, options);
  }

  this.setItems = function(items){
    this.items = items;
  };

  
}



